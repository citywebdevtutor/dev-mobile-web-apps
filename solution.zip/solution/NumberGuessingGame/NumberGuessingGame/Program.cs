﻿using System;

namespace NumberGuessingGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Number Guessing Game!");

            // Generate a random number between 1 and 10 (inclusive)
            Random random = new Random();
            int targetNumber = random.Next(1, 11);
           

            // initialise variables to 0
            int attempts = 0;
            int userGuess = 0;

            // Loop until the user guesses the correct number
            while (userGuess != targetNumber)
            {
                // Prompt the user to enter a guess
                Console.Write("Enter your guess (1-10): ");

                string userInput = Console.ReadLine();
                // Validate user input (ensures user enters a valid integer value between 1 and 10
                // pass/convert user input to an integer and assigns input to userGuess. ! operator means not an integer
                // or userGuess is less that 1 or greater than 10
                if (!int.TryParse(userInput, out userGuess) || userGuess < 1 || userGuess > 10)
                {
                    Console.WriteLine("Invalid input. Please enter a number between 1 and 10.");
                    continue; // Restart the loop if input is invalid
                }

                attempts++; // Increment the attempts counter

                // Check if the guess is correct
                if (userGuess == targetNumber)
                {
                    Console.WriteLine($"Congratulations! You guessed the correct number {targetNumber} in {attempts} attempts.");
                }
                else
                {
                    Console.WriteLine("Incorrect guess. Try again!");
                }
            }

            Console.ReadKey(); // stop program from exiting
        }
    }
}
