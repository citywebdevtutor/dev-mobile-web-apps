﻿using System;

namespace Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Simple Calculator");
            Console.WriteLine("-----------------");

            // Get user input for the first number
            Console.Write("Enter the first number: ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            
            // Get user input for the operation
            Console.Write("Enter the operation (+, -, *, /): ");
            char operation = Console.ReadKey().KeyChar;
            Console.WriteLine(); // Move to the next line after reading the operation

            // Get user input for the second number
            Console.Write("Enter the second number: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            // Perform the calculation based on the selected operation
            double result = 0;

            // Use if-else if-else statements for different operations
            if (operation == '+')
            {
                result = num1 + num2;
            }
            else if (operation == '-')
            {
                result = num1 - num2;
            }
            else if (operation == '*')
            {
                result = num1 * num2;
            }
            else if (operation == '/')
            {
                // Check if the denominator is not zero before performing division
                if (num2 != 0)
                {
                    result = num1 / num2;
                }
                else
                {
                    Console.WriteLine("Error: Division by zero is not allowed.");
                    //return; // Exit the program
                }
            }
            else
            {
                Console.WriteLine("Error: Invalid operation entered.");
                return; // Exit the program
            }

            // Display the result to the user
            //Console.WriteLine("Result: " + num1 + " " + operation + " " + num2 + " = " + result);
            Console.WriteLine($"Result: {num1} {operation} {num2} = {result}");
            Console.ReadKey();
        }
    }
}
