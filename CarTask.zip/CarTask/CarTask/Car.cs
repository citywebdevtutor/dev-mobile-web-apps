﻿using System;

namespace CarTask
{
    internal class Car
    {
        // Attributes
        public string Make;
        public string Model;
        public string Colour;


        // Constructor takes 3 parameters
        public Car(string make, string model, string colour)
        {
            Make = make;
            Model = model;
            Colour = colour;
        }

        // CarInfo() method writes values of car fields to console 
        public void CarInfo()
        {
            Console.WriteLine("My car is a " + Colour + " " + Make + " " + Model);
        }

        // Method to IsMoving takes a string parameter & writes a message if the car is moving based on parameter value.
        public void IsMoving(string move)
        {
            if (move == "yes") // if the value of move is yes
            {
                Console.WriteLine("The " + Colour + " " + Make + " " + Model + " is moving."); // message to console
            }
            else
            {
                Console.WriteLine("The " + Colour + " " + Make + " " + Model + " has stopped."); // message to console
            }

        }
    }
}