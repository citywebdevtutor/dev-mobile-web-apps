﻿using System;

namespace CarTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creating an instance of the Car class
            Car myCar = new Car("Mazda", "3 Sport", "Blue");

            // Displaying initial information
            myCar.CarInfo();

            // Asking the user whether to accelerate 
            Console.WriteLine("Do you want to accelerate? (yes/no): ");
            string userResponse = Console.ReadLine().ToLower(); // convert user input to lower case
            myCar.IsMoving(userResponse); // pass in argument to IsMoving method and return value will be assigned to userMessage

            Console.ReadKey();
        }
    }
}
